# -*- coding: UTF-8 -*-

print("Calcularei a soma dos 50 números pares")

soma=0
for valores in range(0, 101, 2):
    soma=soma+valores

print(f"A soma dos valores é: {soma}")
