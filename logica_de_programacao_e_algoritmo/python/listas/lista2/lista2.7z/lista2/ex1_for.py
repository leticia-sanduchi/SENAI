# -*- coding: UTF-8 -*-

print("Mostrarei todos os números de 1 a 50 e depois invertido, do 50 a 1")
for valores in range(1, 51):
    print(valores)

print("")

for valores2 in range(50, 0, -1):
    print(valores2)
