print("Digite números e calcularei a soma e a média deles. Digite um número negativo para sair")
total=0
contador=0
while True:
    num=float(input("Digite seus números: "))

    if num>0:
        total=total+num
        contador=contador=contador+1

    elif num<0:
        media=total/contador
        print(f"A soma dos números é: {total}")
        print(f"A média dos números é: {media}")

    
