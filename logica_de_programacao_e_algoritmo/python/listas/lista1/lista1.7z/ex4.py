# -*- coding: UTF-8 -*-
print("Escreva um número inteiro e direi se é ímpar ou par")
num=int(input("Digite o número: "))
if num % 2==0:
    print("O número é par")
else:
    print("O número é ímpar")
