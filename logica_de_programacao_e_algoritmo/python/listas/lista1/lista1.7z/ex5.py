# -*- coding: UTF-8 -*-
print("Escreva um número e direi se ele é múltiplo de 3 ou não é múltiplo de  3")
num=int(input("Digite o número: "))
if num%3==0:
    print(f"{num} é múltiplo de 3")
else:
    print(f"{num} não é múltiplo por 3")
