# -*- coding: UTF-8 -*-
print("Diga dois valores inteiros e eu deixarem em ordem crescente")
valor1=float(input("Digite o primeiro valor: "))
valor2=float(input("Digite o segundo valor: "))
if valor1<valor2:
             print(f"{valor1}, {valor2}")
else:
    print (f"{valor2}, {valor1}")
