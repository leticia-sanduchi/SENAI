# -*- coding: UTF-8 -*-

print("Lerei dois números inteiros e vou mostrar o maior")
num1=int(input("Digite o primeiro valor: "))
num2=int(input ("Digite o segundo valor: "))
if num1>num2:
    print("O maior número é: ", num1)
elif num2>num1:
    print("O maior número é: ", num2)
