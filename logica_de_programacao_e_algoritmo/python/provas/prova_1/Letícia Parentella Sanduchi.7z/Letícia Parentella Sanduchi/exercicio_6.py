print("Digite um número e eu exibirei todos os números ímpares de 1 até o número que você digitou")

num = int(input("Digite um número inteiro: "))

for i in range(1,num+1,2):
       print(i)
        
