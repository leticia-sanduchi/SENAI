print("Digite um número inteiro e mostrarei quantos números positivos ele possui até chegar a esse número")

num = int(input("Digite um número inteiro: "))
total = 0

while total <= num:
    total = total + 1
    print(total - 1)
